export interface IUpdateUserDTO{
    name?: string;
    email?: string;

}

export interface IUserDTO {
    _id: string;

    name: string;
    cpf: number;
    email: string;

    papelUsuario:
        | "ADM"
        | "ALUNO"
        | "PROFESSOR";

    active: boolean;

    dt_nascimento?: string;
    participacao_anterior?: boolean;
    estado_civil?: string;
    telefone_principal?: string;
    telefone_secundario?: string;
    profissao?: string;
    problemas_saude?: string;

    createdAt?: string;
    updatedAt?: string;
}